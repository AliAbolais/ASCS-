import React from "react";
import { BrowserRouter } from "react-router-dom";
import AppRoutes from "./routes";
import { ToastContainer } from "react-toastify";
import { Toaster } from "sonner";
import { useRedirectService } from "./authentication/useRedirectService";
import { useAuth } from "./authentication/useAuth";
import LogoutLoadingOverlay from "./components/LogoutLoadingOverlay";

// Component to initialize redirect service inside Router context
const AppWithRedirectService: React.FC = () => {
  useRedirectService(); // Initialize redirect service with navigate function
  const { logoutLoading } = useAuth();

  return (
    <>
      <AppRoutes />
      <ToastContainer
        position="top-center"
        autoClose={3000}
        hideProgressBar={false}
        newestOnTop
        closeOnClick
        rtl={false}
        pauseOnFocusLoss
        draggable
        pauseOnHover
        theme="light"
        style={{ zIndex: 9999 }}
      />
      <Toaster position="top-right" richColors />
      {logoutLoading && <LogoutLoadingOverlay />}
    </>
  );
};

const App: React.FC = () => {
  return (
    <BrowserRouter>
      <AppWithRedirectService />
    </BrowserRouter>
  );
};

export default App;
